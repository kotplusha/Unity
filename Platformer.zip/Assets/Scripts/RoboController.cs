﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoboController : MonoBehaviour {

	public float maxSpeed=10f;
	private bool facingRight=true;
	private float move;
	private bool grounded=false;
	private float groundRadius=0.5f;
	public float jumpForce=100f;
	public bool isShooting=false;
	public float projectileSpeeb=20f;

	private Rigidbody2D rb2d;
	private Animator animator;
	public Transform groundCheck;
	public Transform shootPoint;
	public LayerMask groundMask;
	public GameObject bullet;
	public AudioClip shotSound;
	private AudioSource audioSource;

	// Use this for initialization
	void Start () {
		rb2d = gameObject.GetComponent<Rigidbody2D> ();
		animator = gameObject.GetComponent<Animator> ();
		audioSource = gameObject.GetComponent<AudioSource> ();
	}
	void Update(){
		if (grounded && Mathf.Abs(move)<0.01  && Input.GetKeyDown (KeyCode.Space))
			isShooting = true;
		else
			isShooting = false;

	}
	
	// Update is called once per frame
	void FixedUpdate () {
		if (grounded && (Input.GetKey (KeyCode.UpArrow) || Input.GetKey (KeyCode.W))) {
			Debug.Log ("jump");
			animator.SetBool ("Jump", true);
			rb2d.AddForce (new Vector2 (0, jumpForce));
			animator.SetBool ("Jump", false);
		}

		animator.SetBool ("Shooting", isShooting);
		if (isShooting)
			Shoot ();
		
		grounded = Physics2D.OverlapCircle (groundCheck.position, groundRadius, groundMask);
		animator.SetBool ("Grounded", grounded);

		move = Input.GetAxis ("Horizontal");

		animator.SetFloat ("Speed", Mathf.Abs (move));
			
		rb2d.velocity = new Vector2 (move * maxSpeed, rb2d.velocity.y);

		if ((move > 0 && !facingRight)||(move < 0 && facingRight))
			Flip ();
	}

	void Flip()
	{
		Debug.Log("Flip");
		facingRight = !facingRight;
		Vector3 theScale = transform.localScale;
		theScale.x *= -1;
		transform.localScale = theScale;
	}

	void Shoot()
	{
		GameObject projectile=Instantiate (bullet);
		projectile.transform.position = shootPoint.position;
		projectile.GetComponent<Rigidbody2D> ().velocity = new Vector2 (20 * (facingRight ? 1 : -1),0 );
		audioSource.PlayOneShot (shotSound);
	}

	//GUI sound stuff

	private float volume=1;
	void OnGUI(){
		GUI.Box (new Rect (10, 10, 300, 50), "Shot Volume");
		volume = GUI.HorizontalSlider (new Rect (15, 40, 290, 30), volume, 0, 1);
		audioSource.volume = volume;
	}
}
