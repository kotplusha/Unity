﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
		StartCoroutine (delete());
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	private IEnumerator delete()
	{
		yield return new WaitForSeconds (2);
		Destroy (gameObject);
	}

	public void OnCollisionEnter2D(Collision2D col)
	{
		//Debug.Log (col.gameObject.tag);
		if (col.gameObject.CompareTag ("Trap"))
			Destroy (col.gameObject);
		if(!col.gameObject.CompareTag("Player"))
			Destroy (gameObject);
	}
		
}
